import os
import json
import logging
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    """Processing lambda triggered by S3 event for raw payloads.

    It downloads the raw JSON produced by the ingestion lambda, selects a
    subset of fields (track_name, album_title, composer, milliseconds, unitprice),
    and writes a transformed JSON to the analytics bucket.
    """
    logger.info('Processing lambda invoked')
    # Expect S3 event; support simple records list
    try:
        import boto3
    except Exception:
        raise RuntimeError('boto3 is required in the Lambda environment')

    s3 = boto3.client('s3')
    analytics_bucket = os.environ.get('ANALYTICS_BUCKET')
    if not analytics_bucket:
        raise RuntimeError('ANALYTICS_BUCKET environment variable must be set')

    records = event.get('Records', []) if isinstance(event, dict) else []
    # We'll process each record and write one transformed file per input
    results = []
    for rec in records:
        try:
            s3_info = rec.get('s3', {})
            bucket = s3_info.get('bucket', {}).get('name')
            key = s3_info.get('object', {}).get('key')
            if not bucket or not key:
                logger.warning('Skipping record with missing bucket/key')
                continue

            obj = s3.get_object(Bucket=bucket, Key=key)
            body = obj['Body'].read()
            payload = json.loads(body)
            rows = payload.get('rows', [])

            # Transform: select fields and rename
            transformed = []
            for r in rows:
                transformed.append({
                    'track_id': r.get('TrackId') or r.get('track_id') or r.get('TrackID'),
                    'track_name': r.get('Name') or r.get('track_name') or r.get('name'),
                    'album_title': r.get('Title') or r.get('album_title') or r.get('AlbumTitle'),
                    'composer': r.get('Composer'),
                    'milliseconds': r.get('Milliseconds'),
                    'unit_price': r.get('UnitPrice') or r.get('Unit_Price')
                })

            now = datetime.utcnow().strftime('%Y-%m-%dT%H-%M-%SZ')
            out_key = f'analytics/{now}/{key.split("/")[-1]}'
            out_body = json.dumps({'processed_at': now, 'row_count': len(transformed), 'rows': transformed}, default=str)
            s3.put_object(Bucket=analytics_bucket, Key=out_key, Body=out_body.encode('utf-8'))
            results.append({'input': f's3://{bucket}/{key}', 'output': f's3://{analytics_bucket}/{out_key}', 'rows': len(transformed)})

        except Exception as e:
            logger.exception('Error processing record')
            results.append({'error': str(e)})

    return {'status': 'ok', 'results': results}
